import re
from django import template

register = template.Library()


@register.filter
def initials(value, max_letters=2):
    """'Web Dev' -> 'WD', 'DevOps' -> 'DE', 'AI' -> 'AI'"""
    if not value:
        return "?"
    words = re.findall(r"[A-Za-z0-9]+", value)
    if not words:
        return "?"
    if len(words) == 1:
        return words[0][:max_letters].upper()
    return "".join(w[0] for w in words[:max_letters]).upper()

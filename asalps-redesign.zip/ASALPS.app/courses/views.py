from django.shortcuts import render, redirect, get_object_or_404

from .models import Course, LearningTask


def course_list(request):
    courses = Course.objects.prefetch_related('tasks').all()
    total_tasks = LearningTask.objects.count()
    total_categories = courses.values('category').distinct().count()

    context = {
        'courses': courses,
        'total_paths': courses.count(),
        'total_tasks': total_tasks,
        'total_categories': total_categories,
    }
    return render(request, 'courses/course_list.html', context)


def toggle_task(request, task_id):
    task = get_object_or_404(LearningTask, id=task_id)
    task.is_completed = not task.is_completed
    task.save()
    return redirect('dashboard_index')
